
#include <stdio.h>
#include <unistd.h>

int
main()
{
	printf("Testing write");
	return 0;
}

