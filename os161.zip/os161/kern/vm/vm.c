#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <thread.h>
#include <curthread.h>
#include <addrspace.h>
#include <vm.h>
#include <machine/spl.h>
#include <machine/tlb.h>
#include <vnode.h>
#include <uio.h>
#include <machine/vm.h>
/*
 * Dumb MIPS-only "VM system" that is intended to only be just barely
 * enough to struggle off the ground. You should replace all of this
 * code while doing the VM assignment. In fact, starting in that
 * assignment, this file is not included in your kernel!
 */


//Code most comes from Dumbvm vm part. 
#define DUMBVM_STACKPAGES    12
static int beforeInit = 1;
struct coremapEntry{
	paddr_t pa;
	int state;
	int checkpage;
	int checkexisted;
};
struct coremapEntry* coremap;
unsigned long pageNum;
paddr_t lowAddr, highAddr,freeAddr;


void
vm_bootstrap(void)
{
    int kpage=1;
	int i = 0;
	coremap = kmalloc(PAGE_SIZE); 
	vaddr_t va = alloc_kpages(kpage);	
	while(va != 0){
		coremap[i].pa = KVADDR_TO_PADDR(va);
		coremap[i].state = 0;
		i ++;
		va = alloc_kpages(kpage);
	}
	pageNum = i;
	beforeInit = 0;

}



paddr_t
getppages(unsigned long npages)
{
	assert(npages==1);
	unsigned long i;
	unsigned long blockpage = npages;
	unsigned long startpage = 0;
	paddr_t addr;
	if(beforeInit == 1){
		addr = ram_stealmem(npages);

	}
	else{
		for(i = 0; i<pageNum; i++){
			if(coremap[i].state == 0){
				blockpage--;
			
				if(blockpage == 0){
					break;
				}
			}
			else{
				blockpage = npages;
				startpage = i + 1;
			}
		}


	if(i == pageNum){
		return 0;
	}
	else{
		for(i = 0; i<npages; i++)
		{
			coremap[i+startpage].state = 1;
			coremap[i+startpage].checkexisted = 1;
			coremap[i+startpage].checkpage = startpage;
		}
		addr = coremap[startpage].pa;
	}
	}

	return addr;

}



/* Allocate/free some kernel-space virtual pages */
vaddr_t 
alloc_kpages(int npages)
{
	paddr_t pa;
	pa = getppages(npages);
	if (pa==0) {
		return 0;
	}
	return PADDR_TO_KVADDR(pa);
}

void 
free_kpages(vaddr_t addr)
{

	int check = 0;
	unsigned long i;
	paddr_t paddr = KVADDR_TO_PADDR(addr);
	for(i = 0; i<pageNum;i++){
		if(coremap[i].pa == paddr){
		    check=coremap[i].checkpage;
			break;
		}
	}
    //Since you have to free the stuff, added the following below, and set them to zero.
	while(coremap[i].checkexisted==1 && coremap[i].checkpage==check){
		coremap[i].checkpage = 0;
		coremap[i].state=0;
		coremap[i].checkexisted=0;
		i++;
	}

}




int
vm_fault(int faulttype, vaddr_t faultaddress)
{
	vaddr_t textbot, texttop, databot, datatop, stackbot, stacktop, heapbot,heaptop;
	paddr_t paddr;
	int i;
	u_int32_t ehi, elo;
	struct addrspace *as;
	int spl;

	spl = splhigh();

	faultaddress &= PAGE_FRAME;

	DEBUG(DB_VM, "dumbvm: fault: 0x%x\n", faultaddress);

	switch (faulttype) {
	    case VM_FAULT_READONLY:
		/* We always create pages read-write, so we can't get this */
		panic("dumbvm: got VM_FAULT_READONLY\n");
	    case VM_FAULT_READ:
	    case VM_FAULT_WRITE:
		break;
	    default:
		splx(spl);
		return EINVAL;
	}

	as = curthread->t_vmspace;
	if (as == NULL) {
		/*
		 * No address space set up. This is probably a kernel
		 * fault early in boot. Return EFAULT so as to panic
		 * instead of getting into an infinite faulting loop.
		 */
		return EFAULT;
	}

	/* Assert that the address space has been set up properly. */
	assert(as->as_vbase1 != 0);
	
	assert(as->as_npages1 != 0);
	assert(as->as_vbase2 != 0);

	assert(as->as_npages2 != 0);
	
	assert((as->as_vbase1 & PAGE_FRAME) == as->as_vbase1);

	assert((as->as_vbase2 & PAGE_FRAME) == as->as_vbase2);

	textbot = as->as_vbase1;
	texttop = textbot + ARRAY_SIZE * PAGE_SIZE;
	databot = as->as_vbase2;
	datatop = databot + ARRAY_SIZE * PAGE_SIZE;
	stackbot = USERSTACK - ARRAY_SIZE * PAGE_SIZE;
	stacktop = USERSTACK;
	heapbot = HEAPBOT;
	heaptop = HEAPBOT + ARRAY_SIZE * PAGE_SIZE;




	if (faultaddress >= textbot && faultaddress < texttop) {
		if(curthread->t_vmspace->ntext[(faultaddress-textbot)/PAGE_SIZE].pa != 0){
			paddr = curthread->t_vmspace->ntext[(faultaddress-textbot)/PAGE_SIZE].pa;
		}else{
            //In order to avoid os crash error in malloc test, declare ENOMEM Here for the following 4 tests below. 
			paddr = getppages(1);
	if (paddr == 0) {
				return ENOMEM;           
            }
			curthread->t_vmspace->ntext[(faultaddress-textbot)/PAGE_SIZE].pa = paddr;
		}	
	}
	else if (faultaddress >= databot && faultaddress < datatop) {
		if(curthread->t_vmspace->ndata[(faultaddress-databot)/PAGE_SIZE].pa != 0){
			paddr = curthread->t_vmspace->ndata[(faultaddress-databot)/PAGE_SIZE].pa;			
		}else{
			paddr = getppages(1);
	if (paddr == 0) {
				return ENOMEM;           
            }
			curthread->t_vmspace->ndata[(faultaddress-databot)/PAGE_SIZE].pa = paddr;
		}
	}
	else if (faultaddress >= stackbot && faultaddress < stacktop) {
		if(curthread->t_vmspace->nstack[(stacktop - faultaddress)/PAGE_SIZE].pa != 0){
			 paddr = curthread->t_vmspace->nstack[(stacktop - faultaddress)/PAGE_SIZE].pa;
		}else{
			paddr = getppages(1);
	if (paddr == 0) {
				return ENOMEM;           
            }
			curthread->t_vmspace->nstack[(stacktop - faultaddress)/PAGE_SIZE].pa = paddr;
		
		}
	}
	else if (faultaddress >= heapbot && faultaddress < heaptop) {
			kprintf("tlb: heap_end: %x \n", curthread->t_vmspace->heap_end);
		if(curthread->t_vmspace->nheap[(faultaddress-heapbot)/PAGE_SIZE].pa != 0){
			 paddr = curthread->t_vmspace->nheap[(faultaddress-heapbot)/PAGE_SIZE].pa;	
		}else{
			paddr = getppages(1);

			if (paddr == 0) {
				return ENOMEM;           
            }

			curthread->t_vmspace->nheap[(faultaddress-heapbot)/PAGE_SIZE].pa = paddr;
		}
	}
	else {
		splx(spl);
		return EFAULT;
	}


	/* make sure it's page-aligned */
	assert((paddr & PAGE_FRAME)==paddr);

	for (i=0; i<NUM_TLB; i++) {
		TLB_Read(&ehi, &elo, i);
		if (elo & TLBLO_VALID) {
			continue;
		}
		ehi = faultaddress;
		elo = paddr | TLBLO_DIRTY | TLBLO_VALID;
		DEBUG(DB_VM, "dumbvm: 0x%x -> 0x%x\n", faultaddress, paddr);
		TLB_Write(ehi, elo, i);
		splx(spl);
		return 0;
	}

	kprintf("dumbvm: Ran out of TLB entries - cannot handle page fault\n");
	splx(spl);
	return EFAULT;
}
