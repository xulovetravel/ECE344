/*
 * Invalid calls to close()
 */

#include "test.h"

void
test_close(void)
{
	test_close_fd();
}
