/* 
 * stoplight.c
 *
 * 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
 *
 * NB: You can use any synchronization primitives available to solve
 * the stoplight problem in this file.
 */


/*
 * 
 * Includes
 *
 */

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>
#include <synch.h>

/*
 *
 * Constants
 *
 */

/*
 * Number of cars created.
 */

#define NCARS 20


/*Use Semaphore here to build the directions,and increment the count of cars to pass intersection etc.*/
struct semaphore *NE;
struct semaphore *NW;
struct semaphore *SW;
struct semaphore *SE;
struct semaphore *intersection;

/*
 *
 * Function Definitions
 *
 */

static const char *directions[] = { "N", "E", "S", "W" };

static const char *msgs[] = {
        "approaching:",
        "region1:    ",
        "region2:    ",
        "region3:    ",
        "leaving:    "
};




/* use these constants for the first parameter of message */
enum { APPROACHING, REGION1, REGION2, REGION3, LEAVING };

static void
message(int msg_nr, int carnumber, int cardirection, int destdirection)
{
        kprintf("%s car = %2d, direction = %s, destination = %s\n",
                msgs[msg_nr], carnumber,
                directions[cardirection], directions[destdirection]);
}
 
/*
 * gostraight()
 *
 * Arguments:
 *      unsigned long cardirection: the direction from which the car
 *              approaches the intersection.
 *      unsigned long carnumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement passing straight through the
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
gostraight(unsigned long cardirection,
           unsigned long carnumber)
{
      

    
     if(cardirection==0) { //Case from N to S
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,2);
       P(NW);
       //go south
       message(REGION1,carnumber,cardirection,2);
       P(SW);
       message(REGION2,carnumber,cardirection,2);
       V(NW);
       message(LEAVING,carnumber,cardirection,2);
       V(SW);
      }
    
    
     else if(cardirection==1) { //Case from E to W
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,3);
       P(NE);
       //go west
       message(REGION1,carnumber,cardirection,3);
       P(NW);
       message(REGION2,carnumber,cardirection,3);
       V(NE);
       message(LEAVING,carnumber,cardirection,3);
       V(NW);
      }
    
    
     else if(cardirection==2) {//case from S to N
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,0);
       P(SE);
       //go north
       message(REGION1,carnumber,cardirection,0);
       P(NE);
       message(REGION2,carnumber,cardirection,0);
       V(SE);
       message(LEAVING,carnumber,cardirection,0);
       V(NE);
      }
    
   
    else { //case from W to E
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,1);
       P(SW);
       //go east
       message(REGION1,carnumber,cardirection,1);
       P(SE);
       message(REGION2,carnumber,cardirection,1);
       V(SW);
       message(LEAVING,carnumber,cardirection,1);
       V(SE);
    }
}


/*
 * turnleft()
 *
 * Arguments:
 *      unsigned long cardirection: the direction from which the car
 *              approaches the intersection.
 *      unsigned long carnumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a left turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnleft(unsigned long cardirection,
         unsigned long carnumber)
{
       
     if(cardirection==0) { //Case from NW->SW->SE
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,1);
       P(NW);
       message(REGION1,carnumber,cardirection,1);
       P(SW);
       message(REGION2,carnumber,cardirection,1);
       V(NW);
       P(SE);
       message(REGION3,carnumber,cardirection,1);
       V(SW);
       message(LEAVING,carnumber,cardirection,1);
       V(SE);
      }
    
 
     else if(cardirection==1) {    //Case from NE->NW->SW
       //approaching intersection
       message(APPROACHING,carnumber,cardirection,2);
       P(NE);      
       message(REGION1,carnumber,cardirection,2);
       P(NW);
       message(REGION2,carnumber,cardirection,2);
       V(NE);
       P(SW);
       message(REGION3,carnumber,cardirection,2);
       V(NW);
       message(LEAVING,carnumber,cardirection,2);
       V(SW);
      }
    

     else if(cardirection==2) {    //case from SE->NE->NW
       //approaching intersection
       message(APPROACHING,carnumber,cardirection,3);
       P(SE);      
       message(REGION1,carnumber,cardirection,3);
       P(NE);
       message(REGION2,carnumber,cardirection,3);
       V(SE);
       P(NW);
       message(REGION3,carnumber,cardirection,3);
       V(NE);
       message(LEAVING,carnumber,cardirection,3);
       V(NW);
      }
    

    else  { //case from SW->SE->NE
       //approaching intersection
       message(APPROACHING,carnumber,cardirection,0);
       P(SW);      
       message(REGION1,carnumber,cardirection,0);
       P(SE);
       message(REGION2,carnumber,cardirection,0);
       V(SW);
       P(NE);
       message(REGION3,carnumber,cardirection,0);
       V(SE);
       message(LEAVING,carnumber,cardirection,0);
       V(NE);
    }
}


/*
 * turnright()
 *
 * Arguments:
 *      unsigned long cardirection: the direction from which the car
 *              approaches the intersection.
 *      unsigned long carnumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a right turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnright(unsigned long cardirection,
          unsigned long carnumber)
{

     if(cardirection==0) {//Turn right at NW
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,3);
       P(NW);
       message(REGION1,carnumber,cardirection,3);
       message(LEAVING,carnumber,cardirection,3);
       V(NW);
      }
    
    
     else if(cardirection==1) { //Turn Right at NE
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,0);
       P(NE);
       message(REGION1,carnumber,cardirection,0);
       message(LEAVING,carnumber,cardirection,0);
       V(NE);
      }
    

     else if(cardirection==2) { //Turn right at SE
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,1);
       P(SE);
       message(REGION1,carnumber,cardirection,1);
       message(LEAVING,carnumber,cardirection,1);
       V(SE);
      }
    
   
    else{ //Turn right at SW
       //approcahing intersection
       message(APPROACHING,carnumber,cardirection,2);
       P(SW);
       message(REGION1,carnumber,cardirection,2);
       message(LEAVING,carnumber,cardirection,2);
       V(SW);
    }

}


/*
 * approachintersection()
 *
 * Arguments: 
 *      void * unusedpointer: currently unused.
 *      unsigned long carnumber: holds car id number.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      Change this function as necessary to implement your solution. These
 *      threads are created by createcars().  Each one must choose a direction
 *      randomly, approach the intersection, choose a turn randomly, and then
 *      complete that turn.  The code to choose a direction randomly is
 *      provided, the rest is left to you to implement.  Making a turn
 *      or going straight should be done by calling one of the functions
 *      above.
 */
 
static
void
approachintersection(void * unusedpointer,
                     unsigned long carnumber)
{
        int cardirection;
        int carmode;

        /*
         * Avoid unused variable and function warnings.
         */

    //    (void) unusedpointer;
    //    (void) carnumber;
	//(void) gostraight;
	//(void) turnleft;
	//(void) turnright;
 
       //cardirection and carmode are both set randomly.
        cardirection = random() % 4;
        carmode = random() %3;
        //Add intersection here, since the previous debug had problems with P, maybe have to do with intersection. 
        //That was one factor, another factor was that the problem was I need to change some codes to thread.c 
        P(intersection);
        if(carmode==0) {
            gostraight(cardirection,carnumber);
        }
        else if(carmode==1) {
            turnright(cardirection,carnumber);
        }
        else {
            turnleft(cardirection,carnumber);
        }
        V(intersection);
} 


/*
 * createcars()
 *
 * Arguments:
 *      int nargs: unused.
 *      char ** args: unused.
 *
 * Returns:
 *      0 on success.
 *
 * Notes:
 *      Driver code to start up the approachintersection() threads.  You are
 *      free to modiy this code as necessary for your solution.
 */

int
createcars(int nargs,
           char ** args)
{
        int index, error;

        /*
         * Avoid unused variable warnings.
         */

        //(void) nargs;
        //(void) args;
        NE=sem_create("NE",1);
        SE=sem_create("SE",1);
        NW=sem_create("NW",1);
        SW=sem_create("SW",1);
        //maximum 3 cars get into the intersection, so basically needs 3
        intersection=sem_create("INTERSECTION",3);

        /*
         * Start NCARS approachintersection() threads.
         */

        for (index = 0; index < NCARS; index++) {

                error = thread_fork("approachintersection thread",
                                    NULL,
                                    index,
                                    approachintersection,
                                    NULL
                                    );

                /*
                 * panic() on error.
                 */

                if (error) {
                        
                        panic("approachintersection: thread_fork failed: %s\n",
                              strerror(error)
                              );
                }
        }

        return 0;
}
