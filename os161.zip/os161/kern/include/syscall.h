#ifndef _SYSCALL_H_
#define _SYSCALL_H_

/*
 * Prototypes for IN-KERNEL entry points for system call implementations.
 */

int sys_reboot(int code);
int sys_getpid(void);
int sys_waitpid(pid_t pid, int *status, int options, int *retval);
int sys_write(int fd, const void *buf, size_t nbytes, int *retval);
int sys_read(int fd, char*buf, size_t nbytes, int *retval);
int sys_fork(struct trapframe *tf, int *retval);
int sys_exit(int exitcode);
int sys_execv(char *program, char**uargs);
//int sys_execv(const char *program, char **args, int* retval); 
int sys_time(userptr_t user_secs, userptr_t user_nsecs, int *retval);
#endif /* _SYSCALL_H_ */
