#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <addrspace.h>
#include <thread.h>
#include <curthread.h>
#include <vm.h>
#include <machine/vm.h>
#include <machine/spl.h>
#include <machine/tlb.h>
#include <vnode.h>
#define DUMBVM_STACKPAGES    12

extern unsigned long trackHeapEnd = HEAPBOT;

struct addrspace *
as_create(void)
{
	struct addrspace *as = kmalloc(sizeof(struct addrspace));
	if (as==NULL) {
		return NULL;
	}



	as->as_vbase1 = 0;
	as->as_pbase1 = 0;
	as->as_npages1 = 0;
	as->as_vbase2 = 0;
	as->as_pbase2 = 0;
	as->as_npages2 = 0;
	as->as_stackpbase = 0;

    //added the following
	as->heap_start = trackHeapEnd;
	as->heap_end = trackHeapEnd;
	as->nstack = kmalloc(sizeof(struct page)* ARRAY_SIZE);
	as->nheap = kmalloc(sizeof(struct page)* ARRAY_SIZE);
	as->ndata = kmalloc(sizeof(struct page)* ARRAY_SIZE);
	as->ntext = kmalloc(sizeof(struct page)* ARRAY_SIZE);

	return as;
}


void
as_destroy(struct addrspace *as)
{
    
    //free the text,data,stack,and heap in this function. 
	kfree(as->ntext);
	kfree(as->ndata);	
	kfree(as->nstack);
	kfree(as->nheap);
	kfree(as);

}

void
as_activate(struct addrspace *as)
{
	/*
	 * Write this.
	 */
	int i, spl;

	(void)as;

	/* Disable interrupts on this CPU while frobbing the TLB. */
	spl = splhigh();

	for (i=0; i<NUM_TLB; i++) {
		TLB_Write(TLBHI_INVALID(i), TLBLO_INVALID(), i);
	}

	splx(spl);
	//(void)as;  // suppress warning until code gets written
}


int
as_define_region(struct addrspace *as, vaddr_t vaddr, size_t sz,
		int readable, int writeable, int executable)
{

		size_t npages; 

	/* Align the region. First, the base... */
	sz += vaddr & ~(vaddr_t)PAGE_FRAME;
	vaddr &= PAGE_FRAME;

	/* ...and now the length. */
	sz = (sz + PAGE_SIZE - 1) & PAGE_FRAME;

	npages = sz / PAGE_SIZE;

	/* We don't use these - all pages are read-write */
	(void)readable;
	(void)writeable;
	(void)executable;

	if (as->as_vbase1 == 0) {
		as->as_vbase1 = vaddr;
		as->as_npages1 = npages;
		return 0;
	}

	if (as->as_vbase2 == 0) {
		as->as_vbase2 = vaddr;
		as->as_npages2 = npages;
		return 0;
	}

	/*
	 * Support for more than two regions is not available.
	 */
	kprintf("dumbvm: Warning: too many regions\n");
	return EUNIMP;
}

	

int
as_prepare_load(struct addrspace *as)
{
	assert(as->as_pbase1 == 0);
	assert(as->as_pbase2 == 0);
	assert(as->as_stackpbase == 0);


	/*as->as_pbase1 = getppages(as->as_npages1);
	if (as->as_pbase1 == 0) {
		return ENOMEM;
	}

	as->as_pbase2 = getppages(as->as_npages2);
	if (as->as_pbase2 == 0) {
		return ENOMEM;
	}

	as->as_stackpbase = getppages(DUMBVM_STACKPAGES);
	if (as->as_stackpbase == 0) {
		return ENOMEM;
	}*/


	return 0;	



}

int
as_complete_load(struct addrspace *as)
{
	/*
	 * Write this.
	 */
	(void)as;
	return 0;
}

int
as_define_stack(struct addrspace *as, vaddr_t *stackptr)
{
	/*
	 * Write this.
	 */

	(void)as;

	/* Initial user-level stack pointer */
	*stackptr = USERSTACK;

	return 0;
}



int as_copy(struct addrspace *old, struct addrspace **ret)
{
	struct addrspace *new;

	new = as_create();
	if (new == NULL) {
		return ENOMEM;
	}

    
	new->as_vbase1 = old->as_vbase1;
	new->as_npages1 = old->as_npages1;
	new->as_vbase2 = old->as_vbase2;
	new->as_npages2 = old->as_npages2;

	//copy heap start and heap end.
	new->heap_start = old->heap_start;
	new->heap_end = old->heap_end;






	struct page* stacknew = new->nstack;
	struct page* stackold = old->nstack;
	struct page* heapnew = new->nheap;
	struct page* heapold = old->nheap;
	struct page* datanew = new->ndata;
	struct page* dataold = old->ndata;
	struct page* textnew = new->ntext;
	struct page* textold = old->ntext;
	int i;
    //copied new stack
	for(i =0; i < ARRAY_SIZE; i++){
		if(stackold->pa == 0){
			stackold++;
			stacknew++;
			continue;
		}
		stacknew->pa = KVADDR_TO_PADDR(kmalloc(PAGE_SIZE));
		memcpy((void*)PADDR_TO_KVADDR(stacknew->pa), (const void *)PADDR_TO_KVADDR(stackold->pa), PAGE_SIZE);
		stackold++;
		stacknew++;
	}
	//copied new heap
	for(i =0; i < ARRAY_SIZE; i++){
		if(heapold->pa == 0){
			heapold++;
			heapnew++;
			continue;
		}
	    heapnew->pa = KVADDR_TO_PADDR(kmalloc(PAGE_SIZE));
		memcpy((void*)PADDR_TO_KVADDR(heapnew->pa), (const void *)PADDR_TO_KVADDR(heapold->pa), PAGE_SIZE);
		heapold++;
		heapnew++;
	}
    //copied new data
	for(i =0; i < ARRAY_SIZE; i++){
		if(dataold->pa == 0){
			dataold++;
			datanew++;
			continue;
		}
		datanew->pa = KVADDR_TO_PADDR(kmalloc(PAGE_SIZE));
		memcpy((void*)PADDR_TO_KVADDR(datanew->pa), (const void *)PADDR_TO_KVADDR(dataold->pa), PAGE_SIZE);
		dataold++;
		datanew++;
	}
    //copied new texts
	for(i =0; i < ARRAY_SIZE; i++){
		if(textold->pa == 0){
			textold++;
			textnew++;
			continue;
		}
		textnew->pa = KVADDR_TO_PADDR(kmalloc(PAGE_SIZE));
		memcpy((void*)PADDR_TO_KVADDR(textnew->pa), (const void *)PADDR_TO_KVADDR(textold->pa), PAGE_SIZE);
		textold++;
		textnew++;
	}

	*ret = new;
	return 0;
}
