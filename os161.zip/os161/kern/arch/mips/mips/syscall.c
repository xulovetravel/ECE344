#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <syscall.h>
#include <curthread.h>
#include <thread.h>
#include <synch.h>
#include <kern/unistd.h>
#include <vfs.h>
#include <vnode.h>
#include <uio.h>
#include <clock.h>
#include <addrspace.h>
#include <kern/limits.h>
#include <test.h>
#include <vm.h>
/*
 * System call handler.
 *
 * A pointer to the trapframe created during exception entry (in
 * exception.S) is passed in.
 *
 * The calling conventions for syscalls are as follows: Like ordinary
 * function calls, the first 4 32-bit arguments are passed in the 4
 * argument registers a0-a3. In addition, the system call number is
 * passed in the v0 register.
 *
 * On successful return, the return value is passed back in the v0
 * register, like an ordinary function call, and the a3 register is
 * also set to 0 to indicate success.
 *
 * On an error return, the error code is passed back in the v0
 * register, and the a3 register is set to 1 to indicate failure.
 * (Userlevel code takes care of storing the error code in errno and
 * returning the value -1 from the actual userlevel syscall function.
 * See src/lib/libc/syscalls.S and related files.)
 *
 * Upon syscall return the program counter stored in the trapframe
 * must be incremented by one instruction; otherwise the exception
 * return code will restart the "syscall" instruction and the system
 * call will repeat forever.
 *
 * Since none of the OS/161 system calls have more than 4 arguments,
 * there should be no need to fetch additional arguments from the
 * user-level stack.
 *
 * Watch out: if you make system calls that have 64-bit quantities as
 * arguments, they will get passed in pairs of registers, and not
 * necessarily in the way you expect. We recommend you don't do it.
 * (In fact, we recommend you don't use 64-bit quantities at all. See
 * arch/mips/include/types.h.)
 */
extern unsigned long trackHeapEnd;
void
mips_syscall(struct trapframe *tf)
{
	int callno;
	int32_t retval;
	int err;

	assert(curspl==0);

	callno = tf->tf_v0;

	/*
	 * Initialize retval to 0. Many of the system calls don't
	 * really return a value, just 0 for success and -1 on
	 * error. Since retval is the value returned on success,
	 * initialize it to 0 by default; thus it's not necessary to
	 * deal with it except for calls that return other values, 
	 * like write.
	 */

	retval = 0;
    
    
	switch (callno) {
	    case SYS_reboot:
        //kprintf("you reach reboot!\n");
		err = sys_reboot(tf->tf_a0);
        
		break;
      
	    /* Add stuff here */
          case SYS_getpid:
        //kprintf("you reach getpid!\n");
        retval=sys_getpid();
        err = 0;
        break;


        case SYS_write:
       // kprintf("you reach write !\n");
        err = sys_write(tf->tf_a0, (void*)tf->tf_a1, (size_t)tf->tf_a2, &retval);
        break;

        case SYS_read:
        //kprintf("you reach read!\n");
        err=sys_read(tf->tf_a0, (void*)tf->tf_a1, (size_t)tf->tf_a2, &retval);
        break;

        case SYS_fork:
        //kprintf("you reach fork!\n");
        err = sys_fork(tf,&retval);
        break;
        
   
		case SYS_waitpid:
		err= sys_waitpid(tf->tf_a0, (void*)tf->tf_a1,tf->tf_a2, &retval);
		break;
 
        case SYS__exit:
        err=sys_exit(tf->tf_a0);
        break;

        case SYS_execv:
        err=sys_execv(tf->tf_a0,tf->tf_a1);
        //err=sys_execv2((char*)tf->tf_a0,(char**)tf->tf_a1,&retval);
        break;
        
        case SYS___time:
        err = sys_time((userptr_t)tf->tf_a0,(userptr_t)tf->tf_a1, &retval);
        break;
        
        case SYS_sbrk:
        err=sys_sbrk((int)tf->tf_a0,&retval);
        break;
	    default:
		kprintf("Unknown syscall %d\n", callno);
		err = ENOSYS;
		break;
	}


	if (err) {
		/*
		 * Return the error code. This gets converted at
		 * userlevel to a return value of -1 and the error
		 * code in errno.
		 */
		tf->tf_v0 = err;
		tf->tf_a3 = 1;      /* signal an error */
	}
	else {
		/* Success. */
		tf->tf_v0 = retval;
		tf->tf_a3 = 0;      /* signal no error */
	}
	
	/*
	 * Now, advance the program counter, to avoid restarting
	 * the syscall over and over again.
	 */
	
	tf->tf_epc += 4;

	/* Make sure the syscall code didn't forget to lower spl */
	assert(curspl==0);
}


void
md_forkentry(void *data1, unsigned long data2)
{
	/*
	 * This function is provided as a reminder. You need to write
	 * both it and the code that calls it.
	 *
	 * Thus, you can trash it and do things another way if you prefer.
	 */

	//(void)tf;
   // kprintf("Good6\n");
    struct trapframe tf;
    memcpy(&tf,(struct trapframe*)data1,sizeof(struct trapframe));
    kfree(data1);//Since I copied the memory, I have to free them after using them.
    curthread->t_vmspace=(struct addrspace*)data2;
    as_activate(curthread->t_vmspace);
    tf.tf_v0=0; //signal no error
    tf.tf_a3=0;//signal no error
    tf.tf_epc+=4; //advance the program counter to avoid restarting syscall over again.
    //kprintf("Good7\n");
    mips_usermode(&tf);
}

int sys_getpid(void) {
    return curthread->pid;
}

int sys_waitpid(pid_t pid, int *status, int options, int *retval) {
    // int s=splhigh();
     int invalid_status_1;  int invalid_status_2;
     int pid_2;
     invalid_status_1= 0x80000000; //represents program address between kernel and user mode
     invalid_status_2= 0x40000000; //represents between kernel and address that was not part of the program.

    //The options should be zero, added the case for options that are not zero, and return Einval.
    if(options!=0) {
       //kprintf("111111111\n");
       //kprintf("Wrong1\n");
       *retval = -1;
     //  splx(s);
       return EINVAL;
    }
    
     //Since I defined maximum pid as 512. AND pid cannot be less or equal to zero.
    if((pid<=0)&&(pid>=512)) {
      //kprintf("22222222\n");
      // kprintf("Wrong3\n");
       *retval = -1;
      // splx(s);
       return EINVAL;

    }
    //not part of the program, according to given handout, should return Efault.
    if(status==NULL) {
     //kprintf("3333333\n");
       *retval= -1;
      // splx(s);
       return EINVAL;
    }
//    if(pid==curthread->pid) {
       //kprintf("xiaosi\n");
       //kprintf("Wrong2\n");
    //   *retval= -1;
      // splx(s);
  //     return EINVAL;
 //   }
   // int spl = splhigh();
    
	//if(curthread->t_vmspace != NULL)
	//{
	//	evict_all_my_pages_if_necessary(curthread->t_vmspace);
	//}

   if(pid==curthread->pid) {
       //kprintf("xiaosi\n");
       //kprintf("Wrong2\n");
       *retval= -1;
       //splx(s);
       return EINVAL;
    }
    P(lock);
    struct thread *pid_thread;
   // int check_wait=1;
    int check_exited=get_exited(pid);
   int check_wait=check_waited(pid);
    //if(check_wait==1) {
        
        //V(lock);
       // kprintf("Enter123456\n");
       // return EINVAL;
   // }
    
    //set_waited(pid);

    *retval=pid;
   // if(curthread->t_vmspace != NULL)
	//{
	//	evict_all_my_pages_if_necessary(curthread->t_vmspace);
	//}
    if(check_exited==1) {
        //kprintf("3333333\n");
       
        *status=get_excode(pid);
        V(lock);
       // splx(s);
        return 0;
    }
    else if(check_exited==0) {
        //kprintf("tobe\n");
        pid_thread=find_thread(pid);
        V(lock);
        P(pid_thread->wait);
        *status=get_excode(pid);
        //delete_list(pid);
        //splx(s);
        return 0;
    }
    else if(check_exited==-1) {
        //kprintf("Check\n");
        V(lock);
       // splx(s);
        return EINVAL;
    }
}


int sys_exit(int exitcode) {
     int s=splhigh();
     set_excode(curthread->pid,exitcode);
     //set_exited(curthread->pid);    
     //splx(s);
     //V(curthread->wait);
     thread_exit();
     splx(s);
     return 0;
}


int sys_read(int fd, char*buf, size_t nbytes, int *retval) {
     struct vnode *v;
     struct uio ku;
    if(fd!=STDIN_FILENO) {
         *retval=-1;
         return EBADF;
                          }

    if(buf==NULL)         {
         *retval=-1;
         return EFAULT;
                          }

   char *temp=kmalloc((nbytes+1)*sizeof(char));//need to consider null character, so nybtes+1.
    int i;
    int readcount=0;
    for(i=0; i<(int)nbytes; i++) {
        temp[i]=getch();
        readcount++;
        //If end-of-line
        if(temp[i]=='\r') {
              break;
        }
    }
    temp[readcount]='\0';
    int statcheck= copyout((const void *)temp,(userptr_t)buf, readcount+1);
    //If error occured
    if(statcheck!=0) {
        kfree(temp);//free them each time after using kmalloc
        *retval=-1; //return the error state.
        return EFAULT;
    }
    //if no error occured
    else {
       kfree(temp);//free them each time after using kmalloc
       *retval=readcount; //In this case, return value should be number of counting number of reads.
       return 0;
    }


}
int sys_write(int fd, const void *buf, size_t nbytes, int *retval) {
    struct vnode *v;
    struct uio ku;
    if((fd!=STDOUT_FILENO)&&(fd!=STDERR_FILENO)) {
        //*retval=-1;
         return EBADF;
    }
    
 
    if(buf==NULL) {
         //*retval=-1;
         return EFAULT;
    }
   int statcheck,result;
   char *temp=kmalloc((nbytes+1)*sizeof(char));//need to consider null character, so nybtes+1.
    statcheck= copyin((const_userptr_t)buf, (void *)temp, nbytes+1);
    //If error occured
    if(statcheck!=0) {
        kfree(temp);//free them each time after using kmalloc
        *retval=-1; //return the error state.
        return EFAULT;
    }
    //if no error occured
    else {
       temp[nbytes]='\0'; //Convert the last character back to NULL
       kprintf("%s", temp);//print out the result
       kfree(temp);//free them each time after using kmalloc
       *retval=nbytes; //In this case, return value should be number of bytes.
       return 0;
    }

  
}









/*int sys_exit(int exitcode) {
     int s=splhigh();
     set_excode(curthread->pid,exitcode);
     //set_exited(curthread->pid);    
     //splx(s);
     //V(curthread->wait);
     thread_exit();
     splx(s);
     return 0;
}*/


int sys_execv(char *program, char**uargs){
  #define MAX_PATH_LEN 128 //define the maxium path length
  struct vnode *v;
  vaddr_t entrypoint,stackptr;

  int s=splhigh();//disable all interrupts
  int result;
  if(program==NULL) {//kprintf("name does not exist\n");
       splx(s);
       return EFAULT;}// program path does not exist
  if(uargs==NULL){ 
        //kprintf("arguments does not exist\n");
        splx(s);
        return EFAULT;}// error code EINVAL
  
  /*struct vnode *vn;
  int dir;
  dir=vfs_lookup(program,&vn);// check if program is a directory
  if(dir==0) return EISDIR;*/
  
  //kprintf("you reach 1!\n");
  char* programSize=(char*)kmalloc(MAX_PATH_LEN*sizeof(char));
  size_t size;
  result=copyinstr((const_userptr_t)program,programSize,MAX_PATH_LEN,&size);
  
  if(result){
    //kprintf("1\n");
    kfree(programSize);
    //kprintf("2\n");
    splx(s);
    return EFAULT;// did not copy program to kernel
  }

  if(size==1){
    //kprintf("11\n");
    kfree(programSize);
    //kprintf("22\n");
    splx(s);
    return EINVAL;
  }
  char** nargs=(char*)kmalloc(sizeof(char**));// nargs args in kernel
  result=copyin((const_userptr_t)uargs,nargs,sizeof(char**));
  if(result){
    //kprintf("3\n");
    kfree(programSize);
    kfree(nargs);
    //kprintf("4\n");
    splx(s);
    return EFAULT;
  }
  int i=0;
  
  while (uargs[i]!=NULL){
    nargs[i]=(char*)kmalloc(sizeof(char)*MAX_PATH_LEN);
    result=copyinstr((const_userptr_t)uargs[i],nargs[i],MAX_PATH_LEN,&size);

    if(result){
       //kprintf("5\n");
       kfree(programSize);
       kfree(nargs);
       //kprintf("6\n");
       splx(s);
       return EFAULT;
}
    i++;
}
//kprintf("you reach 2!\n");
//kprintf("%d\n",i);
nargs[i]=NULL;// make the nargv end will NULL pointer



int result1=vfs_open(program,O_RDONLY,&v);//open the file
if(result1){
  //kprintf("7\n");
  splx(s);
  return result1;//can not open
}

//kprintf("you reach 3!\n");

if(curthread->t_vmspace=!NULL){
  //kprintf("you reach 4!\n");
  //as_destroy(curthread->t_vmspace);
  //printf("you reach 5!\n");
  kprintf("critical\n");
  curthread->t_vmspace=NULL;
  //curthread->t_vmspace=as_create();
  }
  
  assert(curthread->t_vmspace==NULL);
  
  curthread->t_vmspace=as_create();
  if(curthread->t_vmspace==NULL){
    //kprintf("8\n");
    vfs_close(v);
    //kprintf("9\n");
    splx(s);
    return ENOMEM;
  }
  
  //  active the address space
  as_activate(curthread->t_vmspace);
  
  int result2=load_elf(v,&entrypoint);

  if(result2){
     vfs_close(v);
     splx(s);
     return result2;
   }

   vfs_close(v);
   int result3=as_define_stack(curthread->t_vmspace,&stackptr);

   if(result3){
     splx(s);
     return result3;
    }
   //kprintf("you reach 6!\n");
//copy argument to stack;
    int length;
    int k=0;

    while(k<i){
    length=1+strlen(nargs[k]);
    int temp=length;

    if(length%4!=0){
       length=length + 4-(length % 4);
    }
    char *arg;
    arg=kmalloc(sizeof(length));
    arg=kstrdup(nargs[k]);
     int i;
    for(i=0;i<length;i++){
      if(i>=temp)
          arg[i]='\0';
          else
          arg[i]=nargs[k][i];
    }
    stackptr=stackptr-length;
    int result4=copyout((const void* )arg,(userptr_t) stackptr, (size_t) length);

    if(result4){
      kfree(programSize);
      kfree(nargs);
      kfree(arg);
      splx(s);
      return result4;
    }
    kfree(arg);
    nargs[k]=(char*) stackptr;
    k++;
    }
 nargs[i]=NULL;
 size_t arg_size=(i+1)*sizeof(char*);
 stackptr-=arg_size;
 stackptr-=stackptr%8;
 copyout(nargs,stackptr,arg_size);

   /* Warp to user mode. */
	md_usermode(k/*argc*/, stackptr /*userspace addr of argv*/,
		    stackptr, entrypoint);
	//kprintf("last step\n");
	/* md_usermode does not return */
	panic("md_usermode returned\n");
    splx(s);
	return EINVAL;

/*for(int i=(k-1);i>=0;i--){
  stackptr-=sizeof(char*);
  result=copyout((const void*) (nargs+i),(userptr_t)stackptr,(sizeof(char*)));
  if(result){
    kfree(programSize);
    kfree(nargs);
    return result;
  }
}*/
   
     
  
}


int sys_time(userptr_t user_secs_ptr, userptr_t user_nsecs_ptr, int *retval){
    time_t secs;
    u_int32_t nanosecs;
    int result;

    gettime(&secs,&nanosecs);

    //Need to have user_secs_ptr to work.
    if(user_secs_ptr != NULL){
        result = copyout(&secs,user_secs_ptr,sizeof(time_t));
        if(result){
            *retval = -1;
            return EFAULT;
        }
    }
    
   // if(user_nsecs_ptr != NULL) {
    result = copyout(&nanosecs,user_nsecs_ptr,sizeof(u_int32_t));
    if(result){
        *retval = -1;
        return EFAULT;
    }
    //}
    *retval = (int)secs;
    return 0;
}



int sys_fork(struct trapframe *tf, int *retval) {
    int s=splhigh();
    //struct thread *child_thread=NULL;
    struct thread* child_thread;
    struct trapframe* child_trapframe=kmalloc(sizeof(struct trapframe));
    //struct addrspace* parent_space;
    struct addrspace* child_space;
    int fork_error;
    if(child_trapframe==NULL) {
       splx(s);
       return ENOMEM;
    }
    memcpy(child_trapframe,tf,sizeof(struct trapframe));
    //parent_space=curthread->t_vmspace;
    int check_status= as_copy(curthread->t_vmspace, &child_space);
    if(check_status!=0) {
        kfree(child_trapframe);
        splx(s);
        return ENOMEM;
    }
    as_activate(curthread->t_vmspace);
    fork_error=thread_fork(curthread->t_name,child_trapframe, (unsigned long)child_space, md_forkentry, &child_thread);
    if(fork_error) {
        kfree(child_trapframe);
        splx(s);
        return ENOMEM;
    }
    *retval=curthread->pid; //Before returning, need to set the return value to the parent id by taking curthread.
    splx(s);
    return 0;
}



int sys_sbrk(int amount, int *retval) {
	struct addrspace * as = curthread->t_vmspace;
	if(amount == 0 ){
		*retval = as->heap_end;
		return 0;
	}

   if((as->heap_end) + amount < as->heap_start || amount < 0){
		*retval = -1;
		return EINVAL;
	}


        //page size: 4096 Array Size:512
   if((as->heap_end + amount) >= as->as_vbase2 + 2*(ARRAY_SIZE * PAGE_SIZE)){
		*retval = -1;
		return ENOMEM;
	}

    *retval = as->heap_end;
	curthread->t_vmspace->heap_end += amount;
	return 0;
}

